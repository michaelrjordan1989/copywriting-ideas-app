import React, { useState } from "react";

const ideaCache = JSON.parse(localStorage.getItem("ideaCache") || "{}");

function saveCache() {
  localStorage.setItem("ideaCache", JSON.stringify(ideaCache));
}

function parseIdeas(raw) {
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function fetchIdeas({ topic, tone, format }) {
  const key = `${topic}|${tone}|${format}`;
  if (ideaCache[key]) return ideaCache[key];

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.REACT_APP_ANTHROPIC_API_KEY,
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 2000,
      system: "You are an expert copywriting assistant. Respond ONLY with raw valid JSON arrays.",
      messages: [{
        role: "user",
        content: `Generate 3 content ideas for topic "${topic}". Tone: ${tone}. Format: ${format}.`
      }]
    })
  });

  const data = await res.json();
  const raw = data.content?.map(b => b.text || "").join("") || "";
  const parsed = parseIdeas(raw);

  if (parsed) {
    ideaCache[key] = parsed;
    saveCache();
  }
  return parsed;
}

function copyIdeaToClipboard(idea) {
  const text = `
${idea.title}
💡 ${idea.hook}
...
CTA: ${idea.cta}
  `.trim();
  navigator.clipboard.writeText(text);
}

function exportIdeaAsMarkdown(idea) {
  const md = `
# ${idea.title}
💡 *${idea.hook}*
...
**CTA:** ${idea.cta}
  `.trim();
  navigator.clipboard.writeText(md);
}

function exportAllIdeasAsMarkdown(ideas) {
  const md = ideas.map((idea, idx) => `# Idea ${idx+1}: ${idea.title}`).join("\n\n---\n\n");
  navigator.clipboard.writeText(md);
}

function downloadIdeasAsMarkdown(ideas) {
  const md = ideas.map((idea, idx) => `# Idea ${idx+1}: ${idea.title}`).join("\n\n---\n\n");
  const blob = new Blob([md], { type: "text/markdown" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "content-ideas.md";
  a.click();
  URL.revokeObjectURL(url);
}

function clearCache() {
  localStorage.removeItem("ideaCache");
  Object.keys(ideaCache).forEach(k => delete ideaCache[k]);
  alert("Cache cleared!");
}

export default function App() {
  const [topic, setTopic] = useState("");
  const [tone, setTone] = useState("Persuasive");
  const [format, setFormat] = useState("Blog Post");
  const [ideas, setIdeas] = useState(null);

  const generate = async () => {
    const parsed = await fetchIdeas({ topic, tone, format });
    setIdeas(parsed);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>AI Copywriting Idea Generator</h1>
      <input value={topic} onChange={e => setTopic(e.target.value)} placeholder="Enter topic..." />
      <button onClick={generate}>Generate Ideas</button>
      <button onClick={clearCache}>🗑️ Clear Cache</button>

      {ideas && (
        <>
          <button onClick={() => exportAllIdeasAsMarkdown(ideas)}>📋 Export All Ideas</button>
          <button onClick={() => downloadIdeasAsMarkdown(ideas)}>💾 Download All Ideas (.md)</button>
          {ideas.map((idea, idx) => (
            <div key={idx} style={{ marginTop: 20, padding: 10, border: "1px solid #ccc" }}>
              <h2>{idea.title}</h2>
              <p>{idea.hook}</p>
              <button onClick={() => copyIdeaToClipboard(idea)}>📋 Copy Outline</button>
              <button onClick={() => exportIdeaAsMarkdown(idea)}>📝 Export Markdown</button>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
